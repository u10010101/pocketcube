#' @title Solve the pocket cube
#'
#' @description The solution is the shortest and is written in standard rotation notation. Due to the pre-stored information of all states, the speed of finding the solution is quite fast.
#'
#' @details The most popular and standard rotation notation is used. Turns for a pocket Cube are represented by the following moves: R, R2, R', U, U2, U', F, F2, F'.
#' These moves correspond to the following actions:
#'
#' R: clockwise rotation of the right face
#'
#' R2: double (180 degrees) clockwise rotation of the right face
#'
#' R': counterclockwise rotation of the right face
#'
#' U: clockwise rotation of the upper face
#'
#' U2: double (180 degrees) clockwise rotation of the upper face
#'
#' U': counterclockwise rotation of the upper face
#'
#' F: clockwise rotation of the front face
#'
#' F2: double (180 degrees) clockwise rotation of the front face
#'
#' F': counterclockwise rotation of the front face
#'
#' When multiple moves are performed in succession, they are executed from left to right.
#'
#' @param cube A string representing the current state of the pocket cube. For the solved state, the string returned by \code{\link{init_cube}} can be used.
#'
#' @return A string representing the solution
#'
#' @examples
#' x=randcube()
#' sol=cube_solve(x)
#' plotcube(x,type="3D")
#' x=op(x,sol)
#' plotcube(x,type="3D")
#'
#' @export
#' @seealso \code{\link{plotcube}} \code{\link{cube_clone}}

cube_solve<-function(cube){
  cube=as.character(cube)
  n=length(cube)
  a=rep("0",n)
  for(i in 1:n){
    a[i]=cube_solve_single(cube[i])
  }
  return(a)
}
